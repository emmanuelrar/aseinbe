<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Aportes extends Model
{
    const CREATED_AT = 'fecha';
}
