<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kdxegre extends Model
{
    //
}
