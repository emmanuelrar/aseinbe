<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Parametros extends Model
{
    //
}
